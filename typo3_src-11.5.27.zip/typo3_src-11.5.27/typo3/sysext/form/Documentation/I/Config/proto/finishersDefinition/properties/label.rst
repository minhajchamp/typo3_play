.. include:: /Includes.rst.txt

This label will be shown within the - :ref:`"Inspector [CollectionElementHeaderEditor]"<typo3.cms.form.prototypes.\<prototypeidentifier>.formelementsdefinition.\<formelementtypeidentifier>.formeditor.editors.*.collectionelementheadereditor>` if the finisher is selected.
