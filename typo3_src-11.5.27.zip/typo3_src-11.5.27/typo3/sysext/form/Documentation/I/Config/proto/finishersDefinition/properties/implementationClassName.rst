.. include:: /Includes.rst.txt

Classname which implements the finisher.
