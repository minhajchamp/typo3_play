.. include:: /Includes.rst.txt

Defines predefined defaults for finisher options which are prefilled, if the finisher is added to a form.
