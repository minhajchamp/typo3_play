<?php

declare(strict_types=1);

use TYPO3\CMS\Extbase\Hook\DataHandler\CheckFlexFormValue;
use TYPO3\CMS\Extbase\Property\TypeConverter\ArrayConverter;
use TYPO3\CMS\Extbase\Property\TypeConverter\BooleanConverter;
use TYPO3\CMS\Extbase\Property\TypeConverter\CoreTypeConverter;
use TYPO3\CMS\Extbase\Property\TypeConverter\DateTimeConverter;
use TYPO3\CMS\Extbase\Property\TypeConverter\FileConverter;
use TYPO3\CMS\Extbase\Property\TypeConverter\FileReferenceConverter;
use TYPO3\CMS\Extbase\Property\TypeConverter\FloatConverter;
use TYPO3\CMS\Extbase\Property\TypeConverter\FolderConverter;
use TYPO3\CMS\Extbase\Property\TypeConverter\IntegerConverter;
use TYPO3\CMS\Extbase\Property\TypeConverter\ObjectConverter;
use TYPO3\CMS\Extbase\Property\TypeConverter\ObjectStorageConverter;
use TYPO3\CMS\Extbase\Property\TypeConverter\PersistentObjectConverter;
use TYPO3\CMS\Extbase\Property\TypeConverter\StringConverter;
use TYPO3\CMS\Extbase\Utility\ExtensionUtility;

defined('TYPO3') or die();

// Register type converters
ExtensionUtility::registerTypeConverter(ArrayConverter::class);
ExtensionUtility::registerTypeConverter(BooleanConverter::class);
ExtensionUtility::registerTypeConverter(DateTimeConverter::class);
ExtensionUtility::registerTypeConverter(FloatConverter::class);
ExtensionUtility::registerTypeConverter(IntegerConverter::class);
ExtensionUtility::registerTypeConverter(ObjectStorageConverter::class);
ExtensionUtility::registerTypeConverter(PersistentObjectConverter::class);
ExtensionUtility::registerTypeConverter(ObjectConverter::class);
ExtensionUtility::registerTypeConverter(StringConverter::class);
ExtensionUtility::registerTypeConverter(CoreTypeConverter::class);
// Experimental FAL<->extbase converters
ExtensionUtility::registerTypeConverter(FileConverter::class);
ExtensionUtility::registerTypeConverter(FileReferenceConverter::class);
ExtensionUtility::registerTypeConverter(FolderConverter::class);

$GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['t3lib/class.t3lib_tcemain.php']['checkFlexFormValue'][] = CheckFlexFormValue::class;
