=========================
TYPO3 extension ``belog``
=========================

View logs from the sys_log table in the TYPO3 backend modules System>Log and
Web>Info>Log.

The TYPO3 backend module System>Log provides a system wide overview and
Web>Info>Log shows logs related to specific pages.

:Repository:  https://github.com/typo3/typo3
:Issues:      https://forge.typo3.org/
:Read online: https://docs.typo3.org/
:TER:         https://extensions.typo3.org/extension/belog/
